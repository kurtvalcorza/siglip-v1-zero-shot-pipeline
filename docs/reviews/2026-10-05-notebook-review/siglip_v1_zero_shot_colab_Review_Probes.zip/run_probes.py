"""Review probes for siglip_v1_zero_shot_colab, torch-free (numpy + pillow). The package __init__ imports torch, so
the probe registers an empty package object and imports config/samples/metrics directly.

P3  fetch the 360 pinned iNaturalist photographs (digest-checked by fetch_corpus), build the 216/48/96 split with
    seed 42, check split disjointness and observer overlap, and recompute the majority and colour-neighbour
    baselines with the carried metrics, to compare with the Kaggle record (0.167 / 0.26 accuracy).
P4  BYOD zip loader + validate_dataset on constructed zips; the BYOD cell's upload branch outside Colab.
"""
import io, json, sys, types, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2])
pkg = types.ModuleType("siglip_v1_pipeline"); pkg.__path__ = [str(repo / "src/siglip_v1_pipeline")]
sys.modules["siglip_v1_pipeline"] = pkg
import importlib
S = importlib.import_module("siglip_v1_pipeline.samples")
M = importlib.import_module("siglip_v1_pipeline.metrics")

files = S.fetch_corpus(cache_dir=str(out / "inat"))
corpus = S.read_corpus(files)
splits = S.build_sample_dataset(corpus, seed=42)
manif = {k: S.validate_dataset(v) for k, v in splits.items()}
splits = {k: m["records"] for k, m in manif.items()}
classes = S.class_names(splits["train"])
res = {"photographs": len(corpus), "bytes": sum(len(v) for v in files.values()), "split": {k: len(v) for k, v in splits.items()},
       "disjoint": S.check_split_disjoint(splits), "observer_overlap": S.observer_overlap(splits),
       "digests": {k: m["digest"][:16] for k, m in manif.items()}}
maj = M.majority_baseline(splits["train"], splits["test"], classes)
nb = M.colour_neighbour_baseline(splits["train"], splits["test"], classes)
pick = lambda d: {k: round(float(d[k]), 3) for k in ("accuracy", "macro_f1", "t2i_map")}
res["P3_baselines"] = {"majority": pick(maj), "colour_neighbour": pick(nb),
                       "kaggle_record": {"majority": {"accuracy": 0.167, "macro_f1": 0.048}, "colour_neighbour": {"accuracy": 0.26, "macro_f1": 0.261}}}

rng = np.random.default_rng(0)
def jpg(w=64, h=64):
    b = io.BytesIO(); Image.fromarray(rng.integers(0, 255, (h, w, 3), dtype=np.uint8)).save(b, "JPEG"); return b.getvalue()
def zf(name, members):
    p = out / name
    with zipfile.ZipFile(p, "w") as z:
        for k, v in members.items(): z.writestr(k, v)
    return p
def ok(n=10, prefix=""):
    rows = ["id,file,label"] + [f"r{i},img{i}.jpg,{'cat' if i % 2 else 'dog'}" for i in range(n)]
    return {f"{prefix}labels.csv": "\n".join(rows) + "\n", **{f"{prefix}img{i}.jpg": jpg() for i in range(n)}}
cases = {
    "ok_10": ok(),
    "wrapping_folder": ok(prefix="mine/"),
    "missing_file": {k: v for k, v in ok().items() if k != "img3.jpg"},
    "no_labels_csv": {k: v for k, v in ok().items() if k != "labels.csv"},
    "one_label": {**ok(), "labels.csv": "id,file,label\n" + "\n".join(f"r{i},img{i}.jpg,dog" for i in range(10)) + "\n"},
    "traversal": {**ok(), "../evil.jpg": jpg()},
    "seven_records": ok(7),
}
p4 = {}
for name, members in cases.items():
    try:
        recs = S.load_byod_dataset(zf(name + ".zip", members))
        m = S.validate_dataset(recs)
        sp = S.split_dataset(recs, seed=42)
        p4[name] = {"accepted": True, "n": m["n_records"], "split": {k: len(v) for k, v in sp.items()}}
    except Exception as exc:
        p4[name] = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"[:220]}
res["P4"] = p4
try:
    exec("from google.colab import files", {})
    res["P4_upload_outside_colab"] = "no error"
except Exception as exc:
    res["P4_upload_outside_colab"] = f"{type(exc).__name__}: {exc}"
src = next("".join(c["source"]) for c in json.loads((repo / "tutorials/siglip_v1_zero_shot_colab.ipynb").read_text())["cells"] if "USE_BYOD = False" in "".join(c["source"]))
res["P4_cell_has_path_field"] = "BYOD_PATH" in src
(out / "results.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
