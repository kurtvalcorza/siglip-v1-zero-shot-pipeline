"""P4b: smallest balanced two-label BYOD set that load_byod_dataset + validate_dataset + split_dataset accept."""
import io, json, sys, types, zipfile
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2])
pkg = types.ModuleType("siglip_v1_pipeline"); pkg.__path__ = [str(repo / "src/siglip_v1_pipeline")]; sys.modules["siglip_v1_pipeline"] = pkg
import importlib; S = importlib.import_module("siglip_v1_pipeline.samples")
rng = np.random.default_rng(1)
def jpg():
    b = io.BytesIO(); Image.fromarray(rng.integers(0, 255, (64, 64, 3), dtype=np.uint8)).save(b, "JPEG"); return b.getvalue()
rows = {}
for n in range(8, 21):
    p = out / f"n{n}.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("labels.csv", "id,file,label\n" + "\n".join(f"r{i},img{i}.jpg,{'cat' if i % 2 else 'dog'}" for i in range(n)) + "\n")
        for i in range(n): z.writestr(f"img{i}.jpg", jpg())
    try:
        sp = S.split_dataset(S.load_byod_dataset(p), seed=42)
        rows[n] = {k: len(v) for k, v in sp.items()}
    except Exception as exc:
        rows[n] = f"{type(exc).__name__}: {exc}"[:120]
print(json.dumps(rows, indent=1))
(out / "p4b_min_size.json").write_text(json.dumps(rows, indent=1))
